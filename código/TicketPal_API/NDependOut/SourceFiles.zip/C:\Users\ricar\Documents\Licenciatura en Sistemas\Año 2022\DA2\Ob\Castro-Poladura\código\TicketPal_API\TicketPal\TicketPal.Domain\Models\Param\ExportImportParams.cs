﻿namespace TicketPal.Domain.Models.Param
{
    public class ExportImportParams
    {
        public string Action { get; set; }
        public string Format { get; set; }
    }
}
