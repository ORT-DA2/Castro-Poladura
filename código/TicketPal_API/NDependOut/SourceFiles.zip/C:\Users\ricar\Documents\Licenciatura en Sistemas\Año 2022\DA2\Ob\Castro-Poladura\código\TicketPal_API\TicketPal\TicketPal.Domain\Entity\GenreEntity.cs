﻿using System.ComponentModel.DataAnnotations;

namespace TicketPal.Domain.Entity
{
    public class GenreEntity : BaseEntity
    {
        public string Name { get; set; }
    }
}
