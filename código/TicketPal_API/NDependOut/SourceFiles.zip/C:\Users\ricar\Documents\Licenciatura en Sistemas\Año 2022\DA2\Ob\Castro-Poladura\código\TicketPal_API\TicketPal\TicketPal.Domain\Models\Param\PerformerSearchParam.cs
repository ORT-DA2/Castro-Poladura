﻿namespace TicketPal.Domain.Models.Param
{
    public class PerformerSearchParam
    {
        public string PerformerName { get; set; }
    }
}
